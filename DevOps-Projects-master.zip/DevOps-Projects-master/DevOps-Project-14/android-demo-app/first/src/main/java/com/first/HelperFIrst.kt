package com.first

fun getResult() = "This is from First module"